package medicalapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class updateprofile extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		HttpSession hs = request.getSession();
		

		try {

			Class.forName("com.mysql.cj.jdbc.Driver");

			String url = "jdbc:mysql://localhost:3306/mms";
			String user = "root";
			String pass = "";
			Connection con = DriverManager.getConnection(url, user, pass);

			String username = request.getParameter("username");//smith
			String old_pass = request.getParameter("oldpass");//hello
			String mobile = request.getParameter("mobile");//90
			String newpass = request.getParameter("newpass");//5454
			String confpass = request.getParameter("confpass");//5454
			String oldusername = request.getParameter("crusername");//admin

			String query = "UPDATE admin SET Username =?,mobile=? WHERE Username=?";			
			PreparedStatement pstmt = con.prepareStatement(query);
			String query2 = "SELECT * from `admin` WHERE  `Password` =?";
			PreparedStatement ps2 = con.prepareStatement(query2);
						
			//pstmt = con.prepareStatement(query);
			try {
				pstmt.setString(1, username);
				pstmt.setString(2, mobile);
				pstmt.setString(3, oldusername);
				ps2.setString(1, old_pass);
				ResultSet rs2 = ps2.executeQuery();
				if(rs2.next()) {
					if(confpass != newpass ) {
						String qurey3 ="UPDATE admin SET Password = ? Where Username=?";
						PreparedStatement ps3 =con.prepareStatement(qurey3);
							ps3.setString(1, newpass);
							ps3.setString(2, oldusername);
							int rs3 =ps3.executeUpdate();					
							if(rs3>0) {
								int rs = pstmt.executeUpdate();
								out.print("<h1>Data Updated...</h1>");								
							}else {
								out.print("<h1>wrong </h1>"+rs3);
							}
					}else {						
						out.print("<h1>Confirm Password is Not Maching with new password</h1>");
					}
				}else {
					out.print("<h1>Wrong Old Password</h1>");
				}
				
			} catch (Exception e) {
				e.printStackTrace();
				out.print("ye bat hai");
			} 
		} catch (Exception e) {
			out.println("Error...");
			e.printStackTrace();
		}

	}

}

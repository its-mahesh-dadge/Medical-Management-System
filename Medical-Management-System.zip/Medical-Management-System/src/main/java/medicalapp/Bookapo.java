package medicalapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class Bookapo extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out = response.getWriter();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url ="jdbc:mysql://localhost:3306/mms";
			String user ="root";
			String pass ="";
			Connection con =DriverManager.getConnection(url,user,pass);
			
			 //declering Variables to store input Values
			 String str_id = request.getParameter("id");
			String name=request.getParameter("name");
			
			String Specialization=request.getParameter("Specialization");
			 
			String str_fee =request.getParameter("fee");
			
			String drname=request.getParameter("drname");
			
			String date=request.getParameter("date");
			int fee =Integer.parseInt(str_fee);
			int id =Integer.parseInt(str_id);
			 
			
			String q2="INSERT INTO `apo_his` (`Id`, `Name`, `Specialization`, `Con_Fee`, `Date`, `drname`) VALUES (?,  ?, ?, ?, ?, ?);";
			PreparedStatement ps =con.prepareStatement(q2);
			ps.setInt(1, id);
			ps.setString(2,name);
			ps.setString(3,Specialization);
			ps.setInt(4,fee);
			ps.setString(5,date);
			ps.setString(6, drname);	
			//ps.setString(6,gender);
			int rowaffect =ps.executeUpdate();
			if(rowaffect>0) {
				//out.println("<font color=red size=14> Patient Added <br> Patient ID:-"+id+"<br> Patient Name:- "+name);
				//out.println("<a href=patientadd.jsp> Add another Patient...</a>");
				out.print("<h1>Appoientment Booked...</h1>");
				out.print("<a href=\"patenthome.jsp\">Back to Home</a>");
			}else {
				out.println("<font color=green size=14> You Entered Wrong Detail..... <br>");
				out.println("<a href=Bookapo.jsp> Fill Details Again...</a>");
				 
			}
		}catch(Exception e) {
			out.print("<h1>Something Went Wrong ...</h2>");
			e.printStackTrace();
		}
	}

}

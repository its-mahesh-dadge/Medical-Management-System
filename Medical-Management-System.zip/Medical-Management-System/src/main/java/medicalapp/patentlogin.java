package medicalapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class patentlogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out = response.getWriter();
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			String url = "jdbc:mysql://localhost:3306/mms";
			String user= "root";
			String pass= "";
			Connection con = DriverManager.getConnection(url, user, pass);
					
			//taking user input and check here
			String username = request.getParameter("txt_username");
			String password = request.getParameter("txt_password");
			String query = "SELECT * from `patient` WHERE `Username` =? AND `Password` =?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet rs =ps.executeQuery();
			if(rs.next()) {
				//if provided  Data is present in table in this "Home.jsp" will execute..
				//jump to another page
				RequestDispatcher rd = request.getRequestDispatcher("patenthome.jsp");
				rd.forward(request, response);
			}else {
				out.println("<font color=red size=14> Login Failed...!! <br>");
				out.println("<a href=login.jsp> Try Again...</a>");
			}
		} catch (Exception e) {
			e.printStackTrace();
			out.println("<font color=red size=14> Check Connections...<br>");
			  
		}
		
	}

}

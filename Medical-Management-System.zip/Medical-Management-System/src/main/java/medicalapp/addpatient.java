package medicalapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class addpatient extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out = response.getWriter();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url ="jdbc:mysql://localhost:3306/mms";
			String user ="root";
			String pass ="";
			Connection con =DriverManager.getConnection(url,user,pass);
			
			 //declering Variables to store input Values
			String str_id =request.getParameter("id");
			String name=request.getParameter("name");
			String str_age=request.getParameter("age");
			String str_contact=request.getParameter("contact");
			String med_his=request.getParameter("med_his");
			String gender=request.getParameter("gender");
			int id =Integer.parseInt(str_id);
			int age =Integer.parseInt(str_age);
			int contact=Integer.parseInt(str_contact);
			String q2="INSERT INTO `docpatient` (`id`, `name`, `age`, `contact`, `med_his`, `gender`) VALUES (?,?,?,?,?,?)";
			PreparedStatement ps =con.prepareStatement(q2);
			ps.setInt(1,id);
			ps.setString(2,name);
			ps.setInt(3,age);
			ps.setInt(4, contact);
			ps.setString(5,med_his);
			ps.setString(6,gender);
			int rowaffect =ps.executeUpdate();
			if(rowaffect>0) {
				out.println("<font color=red size=14> Patient Added <br> Patient ID:-"+id+"<br> Patient Name:- "+name);
				out.println("<a href=patientadd.jsp> Add another Patient...</a>");
				 
			}else {
				out.println("<font color=green size=14> Missing Something... <br>");
				out.println("<a href=patientadd.jsp> Fill Details Again...</a>");
				 
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}

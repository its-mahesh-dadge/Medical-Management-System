How to run the Hospital Management System (HMS) Project
1. Download the  zip file

2. Extract the file and imprt in to Eclips

3. // Database file .... mms.sql.....

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name mms

6. Import mms.sql file(given inside the zip Medical_Store_Management\Database)

7.Run the index.jsp

Login Details
Login Details for Patient: bob/bob@123
Login Details for Doctor: dr jenny/jenny@123
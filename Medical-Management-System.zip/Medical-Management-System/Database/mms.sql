-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 07, 2024 at 07:51 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `Specialization` varchar(20) NOT NULL,
  `email` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Username`, `Password`, `mobile`, `Specialization`, `email`) VALUES
('dr jenny', 'jenny@123', '9022456541', 'Ayurvdea', 'dr.jenny1@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `apo_his`
--

CREATE TABLE `apo_his` (
  `Id` int(10) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Specialization` varchar(20) NOT NULL,
  `Con_Fee` int(6) NOT NULL,
  `Date` varchar(25) NOT NULL,
  `drname` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `apo_his`
--

INSERT INTO `apo_his` (`Id`, `Name`, `Specialization`, `Con_Fee`, `Date`, `drname`) VALUES
(101, 'bunny', 'asthema', 600, '12-jun-2023', 'pending'),
(102, 'sunny', 'asthema', 600, '12-jun-2023', 'pending'),
(103, 'mahi', 'headh', 600, '24-02-23', 'ok');

-- --------------------------------------------------------

--
-- Table structure for table `docpatient`
--

CREATE TABLE `docpatient` (
  `id` int(20) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `age` int(2) DEFAULT NULL,
  `contact` int(10) NOT NULL,
  `med_his` varchar(50) NOT NULL,
  `gender` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `docpatient`
--

INSERT INTO `docpatient` (`id`, `name`, `age`, `contact`, `med_his`, `gender`) VALUES
(1, 'bunny', 21, 7878525, 'Asthama patient', 'male'),
(63, 'sunil', 32, 4585245, 'headech', 'Male'),
(85, 'Mahesh Dadge', 21, 4585245, 'headech', 'Male'),
(123, 'Mahesh Dadge', 21, 4585245, 'headech', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `mobile` int(10) NOT NULL,
  `email` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`Username`, `Password`, `mobile`, `email`) VALUES
('bob', 'bob@123', 85245273, 'bob123@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `apo_his`
--
ALTER TABLE `apo_his`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `docpatient`
--
ALTER TABLE `docpatient`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`Username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `apo_his`
--
ALTER TABLE `apo_his`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64739;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
